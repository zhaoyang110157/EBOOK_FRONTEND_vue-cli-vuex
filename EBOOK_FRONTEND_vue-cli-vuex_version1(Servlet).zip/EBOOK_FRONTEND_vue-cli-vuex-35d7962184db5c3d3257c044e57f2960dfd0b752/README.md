EBook
==

EBook是一个在线图书购买平台，为SE228课程项目实践

EBOOK_FRONTEND_vue-cli-vuex，此部分为前端project


技术栈
---

  1.Vue

  2.ElementUI

  3.Bootstrap

  4.axios

  5.vue-router

  6.vuex

  7.vue-cli

更新日志
---

  2019.3.31 更新

    本次更新基本完成了前端所有的静态页面，包括书籍、订单、购物车、搜索等，并用Vue框架实现交互逻辑

